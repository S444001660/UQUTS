import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart'; // مكتبة لمسح الباركود باستخدام الكاميرا.
import 'package:uuid/uuid.dart'; // لتوليد معرفات فريدة (IDs).
import 'dart:developer'
    as developer; // لتسجيل الأخطاء والرسائل التشخيصية المتقدمة.

import '../models/device_model.dart'; // نموذج بيانات الجهاز.
import '../models/lab_model.dart'; // نموذج بيانات المعمل.
import 'package:uquts1/services/firebase_database_service.dart';
import '../screens/view_device_screen.dart'; // الشاشة الجديدة لعرض الجهاز فقط.
import '../screens/add_device_screen.dart'; // شاشة إضافة/تعديل جهاز.
import '../utils/ui_helpers.dart'; // دوال مساعدة لعرض عناصر واجهة المستخدم.
import '../utils/barcode_utils.dart'; // دوال مساعدة لتحليل بيانات الباركود.
import '../utils/validation_utils.dart'; // دوال التحقق من صحة المدخلات.
import '../utils/device_form_constants.dart'; // ثوابت وقوائم مستخدمة في الفورم.

// ويدجت شاشة ماسح الباركود، وهي StatefulWidget لأن حالتها تتغير.
class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});

  @override
  BarcodeScannerScreenState createState() => BarcodeScannerScreenState();
}

// كلاس الحالة (State) الخاص بـ BarcodeScannerScreen.
class BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  // متحكم (Controller) للتحكم في ماسح الباركود (الكاميرا).
  final MobileScannerController _scannerController = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal, // سرعة اكتشاف الباركود.
    facing: CameraFacing.back, // استخدام الكاميرا الخلفية افتراضيًا.
    autoStart: false, // <--- مهم جداً: تعطيل التشغيل التلقائي
  );

  List<LabModel> _availableLabs = []; // قائمة لتخزين المعامل المتاحة.
  bool _isLoading = false; // لتتبع حالة تحميل المعامل.

  @override
  void initState() {
    super.initState();
    _loadLabs(); // تحميل قائمة المعامل عند بدء الشاشة.
    // بدء الماسح الضوئي فوراً عند تهيئة الشاشة
    _startScanner(); // الآن نتحكم نحن في البدء يدوياً
    developer.log(
        'BarcodeScannerScreen: Scanner initialized and explicitly starting in initState.');
  }

  // دالة لبدء الماسح الضوئي
  void _startScanner() {
    Future.microtask(() async {
      if (!mounted) {
        developer.log(
            'BarcodeScannerScreen: _startScanner called but widget is not mounted.');
        return;
      }
      try {
        // استدعاء start() مباشرة. بما أن autoStart: false، فهذا آمن.
        await _scannerController.start();
        developer.log('BarcodeScannerScreen: Scanner started successfully.');
      } catch (e) {
        developer.log('BarcodeScannerScreen: Error starting scanner: $e');
        if (mounted) {
          UIHelpers.showErrorSnackBar(context, 'خطأ في بدء الماسح الضوئي: $e');
        }
      }
    });
  }

  // دالة لإيقاف الماسح الضوئي
  void _stopScanner() {
    Future.microtask(() async {
      if (!mounted) {
        developer.log(
            'BarcodeScannerScreen: _stopScanner called but widget is not mounted.');
        return;
      }
      try {
        // استدعاء stop() مباشرة.
        await _scannerController.stop();
        developer.log('BarcodeScannerScreen: Scanner stopped successfully.');
      } catch (e) {
        developer.log('BarcodeScannerScreen: Error stopping scanner: $e');
        if (mounted) {
          UIHelpers.showErrorSnackBar(
              context, 'خطأ في إيقاف الماسح الضوئي: $e');
        }
      }
    });
  }

  @override
  void dispose() {
    _stopScanner(); // إيقاف الماسح عند التخلص من الويدجت
    _scannerController.dispose(); // التخلص من متحكم الكاميرا.
    developer.log('BarcodeScannerScreen: Scanner disposed in dispose.');
    super.dispose();
  }

  // دالة غير متزامنة لتحميل قائمة المعامل من قاعدة البيانات.
  Future<void> _loadLabs() async {
    setState(() => _isLoading = true);
    try {
      final labs = await FirebaseDatabaseService.getLabs();
      setState(() {
        _availableLabs = labs;
        _isLoading = false;
      });
      developer.log(
          'BarcodeScannerScreen: Labs loaded successfully. Count: ${labs.length}');
    } catch (e) {
      developer.log('Error loading labs',
          name: 'BarcodeScannerScreen',
          level: 1000, // مستوى الخطورة (SEVERE).
          error: e,
          stackTrace: StackTrace.current);

      if (mounted) {
        UIHelpers.showSnackBar(
          context: context,
          message: 'خطأ في تحميل المعامل: ${e.toString()}',
          type: SnackBarType.error,
        );
        setState(() => _isLoading = false);
      }
    }
  }

  // دالة لمعالجة الباركود بعد مسحه.
  Future<void> _handleBarcodeScan(BarcodeCapture capture) async {
    if (capture.barcodes.isEmpty) {
      developer.log('BarcodeScannerScreen: No barcode detected.');
      return;
    }

    _stopScanner(); // إيقاف الماسح مؤقتاً لمنع المسح المتكرر أثناء معالجة الباركود
    developer
        .log('BarcodeScannerScreen: Scanner stopped due to barcode detection.');

    final barcode = capture.barcodes.first;
    developer
        .log('BarcodeScannerScreen: Barcode detected: ${barcode.rawValue}');

    final barcodeData = BarcodeUtils.parseUniversityBarcode(barcode);

    final existingDevice = await _checkDeviceExists(barcodeData);

    if (existingDevice != null) {
      _showExistingDeviceDialog(existingDevice);
    } else {
      _navigateToNewDeviceRegistration(barcodeData);
    }
  }

  // دالة للتحقق من وجود الجهاز في قاعدة البيانات بناءً على بيانات الباركود.
  Future<DeviceModel?> _checkDeviceExists(
      Map<String, String?> barcodeData) async {
    try {
      developer.log(
          'BarcodeScannerScreen: Checking if device exists for barcode/assetCode: ${barcodeData['barcode'] ?? ''} / ${barcodeData['assetCode'] ?? ''}');
      final device = await FirebaseDatabaseService.getDeviceByBarcode(
        barcodeData['barcode'] ?? '',
        barcodeData['assetCode'] ?? '',
      );
      if (device != null) {
        developer.log('BarcodeScannerScreen: Device found: ${device.name}');
      } else {
        developer.log('BarcodeScannerScreen: Device not found.');
      }
      return device;
    } catch (e) {
      developer.log('Error checking device existence',
          name: 'BarcodeScannerScreen',
          level: 1000,
          error: e,
          stackTrace: StackTrace.current);
      return null;
    }
  }

  // دالة لعرض نافذة منبثقة للجهاز الموجود بالفعل.
  void _showExistingDeviceDialog(DeviceModel device) {
    developer.log(
        'BarcodeScannerScreen: Showing existing device dialog for ${device.name}.');
    showDialog(
      context: context,
      barrierDismissible: false, // لا يمكن إغلاقه بالنقر خارجاً
      builder: (context) {
        return AlertDialog(
          title: const Text('جهاز موجود بالفعل'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('تم العثور على الجهاز: ${device.name}',
                  textAlign: TextAlign.center),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  developer.log(
                      'BarcodeScannerScreen: "View Device Details" button pressed for existing device.');
                  Navigator.pop(context); // إغلاق AlertDialog
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ViewDeviceScreen(device: device),
                    ),
                  ).then((_) {
                    developer.log(
                        'BarcodeScannerScreen: Returned from ViewDeviceScreen, restarting scanner.');
                    _startScanner(); // إعادة تشغيل الماسح الضوئي
                  });
                },
                child: const Text('عرض تفاصيل الجهاز'),
              ),
            ],
          ),
        );
      },
    ).then((_) {
      developer.log(
          'BarcodeScannerScreen: Existing device dialog dismissed (external dismissal or pop), restarting scanner.');
      _startScanner(); // إعادة تشغيل الماسح الضوئي
    });
  }

  // دالة للانتقال إلى شاشة تسجيل جهاز جديد مباشرة
  void _navigateToNewDeviceRegistration(Map<String, String?> barcodeData) {
    developer.log(
        'BarcodeScannerScreen: Navigating to AddDeviceScreen for new device registration.');
    if (_availableLabs.isEmpty) {
      UIHelpers.showSnackBar(
        context: context,
        message: 'لا توجد معامل متاحة للتسجيل',
        type: SnackBarType.error,
      );
      _startScanner(); // أعد تشغيل الماسح الضوئي إذا لم تكن هناك معامل
      developer
          .log('BarcodeScannerScreen: No labs available, restarting scanner.');
      return;
    }

    // لا نمرر labId هنا، لأن المستخدم سيختاره في AddDeviceScreen
    // ونمرر scannedBarcodeData لملء الحقول تلقائياً
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddDeviceScreen(scannedBarcodeData: barcodeData),
      ),
    ).then((_) {
      // عند العودة من شاشة AddDeviceScreen، أعد تشغيل الماسح الضوئي
      developer.log(
          'BarcodeScannerScreen: Returned from AddDeviceScreen (new device), restarting scanner.');
      _startScanner();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مسح الباركود'),
        actions: [
          // زر للتحكم في فلاش الكاميرا (أيقونة ثابتة).
          IconButton(
            icon:
                const Icon(Icons.flash_on, color: Colors.grey), // أيقونة ثابتة
            onPressed: () {
              _scannerController.toggleTorch();
              developer.log('BarcodeScannerScreen: Torch toggled.');
            },
          ),
          // زر للتبديل بين الكاميرا الأمامية والخلفية (أيقونة ثابتة).
          IconButton(
            icon: const Icon(Icons.camera_rear), // أيقونة ثابتة
            onPressed: () {
              _scannerController.switchCamera();
              developer.log('BarcodeScannerScreen: Camera switched.');
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : MobileScanner(
              controller: _scannerController,
              onDetect: _handleBarcodeScan,
            ),
    );
  }
}
