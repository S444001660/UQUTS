import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart' show debugPrint;
import 'dart:io';
import 'package:path/path.dart' as path;
import 'package:uuid/uuid.dart';

import '../models/lab_model.dart';
import '../models/device_model.dart';

// تعريف LabStatus إذا لم يكن في LabModel.dart
// enum LabStatus { openWithDevices, openNoDevices, closed }

class FirebaseDatabaseService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final FirebaseStorage _storage = FirebaseStorage.instance;

  // ---------------------------------------------------------------------------
  // عمليات المعامل (Labs)
  // ---------------------------------------------------------------------------

  // إضافة معمل جديد أو تحديث موجود
  static Future<void> addOrUpdateLab(LabModel lab) async {
    try {
      // التحقق من صحة البيانات الأساسية
      if (lab.id.isEmpty ||
          lab.labNumber.isEmpty ||
          lab.college.isEmpty ||
          lab.department.isEmpty) {
        throw Exception('بيانات المعمل الأساسية غير صالحة أو مفقودة.');
      }

      // تحويل LabModel إلى Map جاهزة لـ Firestore
      final Map<String, dynamic> labData = lab.toMap();

      // إذا كان هناك imagePath محلي، قم بتحميله إلى Storage واحفظ الـ URL
      if (lab.imagePath != null &&
          lab.imagePath!.isNotEmpty &&
          !lab.imagePath!.startsWith('http')) {
        // هنا يتم استدعاء الدالة العامة لرفع الصورة
        final imageUrl = await uploadImageToFirebaseStorage(
            File(lab.imagePath!), 'lab_images/${lab.id}');
        labData['imagePath'] = imageUrl;
      }

      // إضافة أو تحديث المستند في مجموعة 'labs' باستخدام الـ ID الخاص بالمعمل
      await _firestore
          .collection('labs')
          .doc(lab.id)
          .set(labData, SetOptions(merge: true));
      debugPrint('تم إضافة/تحديث المعمل بنجاح: ${lab.labNumber}');
    } catch (e) {
      debugPrint('خطأ في إضافة/تحديث المعمل: $e');
      rethrow; // إعادة رمي الخطأ للتعامل معه في واجهة المستخدم
    }
  }

  // حذف معمل
  static Future<void> deleteLab(String labId) async {
    try {
      // حذف المعمل من Firestore
      await _firestore.collection('labs').doc(labId).delete();

      // تحديث الأجهزة المرتبطة: إزالة مرجع labId
      // يمكن استخدام Batch Write لتحسين الأداء إذا كان هناك عدد كبير من الأجهزة
      final devicesSnapshot = await _firestore
          .collection('devices')
          .where('labId', isEqualTo: labId)
          .get();
      final batch = _firestore.batch();
      for (var doc in devicesSnapshot.docs) {
        batch.update(doc.reference, {'labId': null}); // تعيين labId إلى null
      }
      await batch.commit();

      // حذف الصورة المرتبطة بالمعمل من Storage (اختياري)
      await _deleteImageFromFirebaseStorage('lab_images/$labId');

      debugPrint('تم حذف المعمل بنجاح: $labId');
    } catch (e) {
      debugPrint('خطأ في حذف المعمل: $e');
      rethrow;
    }
  }

  // تحديث حالة المعمل (بناءً على وجود الأجهزة)
  static Future<void> updateLabStatus(String labId) async {
    try {
      final devicesSnapshot = await _firestore
          .collection('devices')
          .where('labId', isEqualTo: labId)
          .get();
      final deviceCount = devicesSnapshot.docs.length;

      // يجب أن يكون LabStatus معرفًا في مكان ما، عادة في LabModel.dart
      // إذا لم يكن معرفًا، افترض تعريفًا هنا أو قم بإزالته إذا لم يكن مستخدمًا
      // For example, if LabStatus is an enum in LabModel.dart:
      // final newStatus = deviceCount > 0 ? LabStatus.openWithDevices.name : LabStatus.openNoDevices.name;

      // افتراضًا أن LabStatus هو enum في LabModel.dart ولديه .name
      final newStatus = deviceCount > 0
          ? LabStatus.openWithDevices.name
          : LabStatus.openNoDevices.name;

      await _firestore.collection('labs').doc(labId).update({
        'status': newStatus,
        'updatedAt': Timestamp.fromDate(DateTime.now()), // استخدام Timestamp
      });
      debugPrint('تم تحديث حالة المعمل $labId إلى $newStatus');
    } catch (e) {
      debugPrint('خطأ في تحديث حالة المعمل: $e');
      rethrow;
    }
  }

  // جلب جميع المعامل
  static Future<List<LabModel>> getLabs() async {
    try {
      final QuerySnapshot snapshot = await _firestore.collection('labs').get();
      return snapshot.docs
          .map((doc) => LabModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('خطأ في جلب المعامل: $e');
      return [];
    }
  }

  // جلب المعامل حسب الكلية (مضافة حديثًا)
  static Future<List<LabModel>> getLabsByCollege(String college) async {
    try {
      final QuerySnapshot snapshot = await _firestore
          .collection('labs')
          .where('college', isEqualTo: college)
          .get();
      return snapshot.docs
          .map((doc) => LabModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('خطأ في جلب المعامل حسب الكلية: $e');
      return [];
    }
  }

  // جلب معمل بواسطة الـ ID
  static Future<LabModel?> getLabById(String labId) async {
    try {
      final DocumentSnapshot doc =
          await _firestore.collection('labs').doc(labId).get();
      if (doc.exists && doc.data() != null) {
        return LabModel.fromMap(doc.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      debugPrint('خطأ في جلب المعمل بواسطة ID: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // عمليات الأجهزة (Devices)
  // ---------------------------------------------------------------------------

  // إضافة جهاز جديد أو تحديث موجود
  static Future<void> addOrUpdateDevice(DeviceModel device) async {
    try {
      // تحويل DeviceModel إلى Map جاهزة لـ Firestore
      final Map<String, dynamic> deviceData = device.toMap();

      // إذا كان هناك imagePath محلي (وليس URL)، قم بتحميله إلى Storage واحفظ الـ URL
      if (device.imagePath != null &&
          device.imagePath!.isNotEmpty &&
          !device.imagePath!.startsWith('http')) {
        final imageUrl = await uploadImageToFirebaseStorage(
            File(device.imagePath!), 'device_images/${device.id}');
        deviceData['imagePath'] = imageUrl;
      }

      // إضافة أو تحديث المستند في مجموعة 'devices' باستخدام الـ ID الخاص بالجهاز
      await _firestore
          .collection('devices')
          .doc(device.id)
          .set(deviceData, SetOptions(merge: true));

      // تحديث حالة المعمل المرتبط بالجهاز
      await updateLabStatus(device.labId);
      debugPrint('تم إضافة/تحديث الجهاز بنجاح: ${device.name}');
    } catch (e) {
      debugPrint('خطأ في إضافة/تحديث الجهاز: $e');
      rethrow;
    }
  }

  // حذف جهاز
  static Future<void> deleteDevice(String deviceId) async {
    try {
      // الحصول على labId قبل الحذف لتحديث حالة المعمل
      final deviceDoc =
          await _firestore.collection('devices').doc(deviceId).get();
      String? labId;
      String? imagePath; // للحصول على مسار الصورة لحذفها من Storage
      if (deviceDoc.exists && deviceDoc.data() != null) {
        final data = deviceDoc.data() as Map<String, dynamic>;
        labId = data['labId'];
        imagePath = data['imagePath'];
      }

      await _firestore.collection('devices').doc(deviceId).delete();

      // حذف الصورة المرتبطة بالجهاز من Storage (اختياري)
      if (imagePath != null && imagePath.isNotEmpty) {
        // استخراج المسار النسبي من الـ URL الكامل
        try {
          final storageRef = _storage.refFromURL(imagePath);
          await storageRef.delete();
        } catch (e) {
          debugPrint(
              'خطأ في حذف صورة الجهاز من Storage (قد لا تكون موجودة): $e');
        }
      }

      // تحديث حالة المعمل إذا كان الجهاز مرتبطًا بمعمل
      if (labId != null) {
        await updateLabStatus(labId);
      }
      debugPrint('تم حذف الجهاز بنجاح: $deviceId');
    } catch (e) {
      debugPrint('خطأ في حذف الجهاز: $e');
      rethrow;
    }
  }

  // جلب جهاز بواسطة الـ ID (جديد)
  static Future<DeviceModel?> getDeviceById(String deviceId) async {
    try {
      final DocumentSnapshot doc =
          await _firestore.collection('devices').doc(deviceId).get();
      if (doc.exists && doc.data() != null) {
        return DeviceModel.fromMap(doc.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      debugPrint('خطأ في جلب الجهاز بواسطة ID: $e');
      return null;
    }
  }

  // جلب جميع الأجهزة
  static Future<List<DeviceModel>> getDevices() async {
    try {
      final QuerySnapshot snapshot =
          await _firestore.collection('devices').get();
      return snapshot.docs
          .map((doc) => DeviceModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('خطأ في جلب الأجهزة: $e');
      return [];
    }
  }

  // جلب الأجهزة لمعمل معين
  static Future<List<DeviceModel>> getDevicesForLab(String labId) async {
    try {
      final QuerySnapshot snapshot = await _firestore
          .collection('devices')
          .where('labId', isEqualTo: labId)
          .get();
      return snapshot.docs
          .map((doc) => DeviceModel.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      debugPrint('خطأ في جلب الأجهزة للمعمل: $e');
      return [];
    }
  }

  // البحث عن الأجهزة
  static Future<List<DeviceModel>> searchDevices(String query) async {
    try {
      // البحث في Firestore يتطلب استعلامات دقيقة أو استخدام Cloud Functions + Algolia/Elasticsearch
      // هذا مثال بسيط للبحث عن طريق حقل واحد (serialNumber)
      // للبحث النصي الكامل، ستحتاج إلى حلول بحث متقدمة مع Firestore
      final QuerySnapshot nameSnapshot = await _firestore
          .collection('devices')
          .where('name', isGreaterThanOrEqualTo: query)
          .where('name', isLessThanOrEqualTo: query + '\uf8ff')
          .get();

      final QuerySnapshot serialSnapshot = await _firestore
          .collection('devices')
          .where('serialNumber', isGreaterThanOrEqualTo: query)
          .where('serialNumber', isLessThanOrEqualTo: query + '\uf8ff')
          .get();

      // دمج النتائج وإزالة التكرارات
      final Set<DeviceModel> uniqueDevices = {};
      nameSnapshot.docs.forEach((doc) => uniqueDevices
          .add(DeviceModel.fromMap(doc.data() as Map<String, dynamic>)));
      serialSnapshot.docs.forEach((doc) => uniqueDevices
          .add(DeviceModel.fromMap(doc.data() as Map<String, dynamic>)));

      return uniqueDevices.toList();
    } catch (e) {
      debugPrint('خطأ في البحث عن الأجهزة: $e');
      return [];
    }
  }

  // التحقق مما إذا كان الرقم التسلسلي موجودًا
  static Future<bool> serialNumberExists(String serialNumber,
      {String? excludeId}) async {
    try {
      Query query = _firestore
          .collection('devices')
          .where('serialNumber', isEqualTo: serialNumber);
      if (excludeId != null) {
        // إذا كنا نتحقق من التكرار أثناء التحديث، استبعد الجهاز الحالي
        query = query.where('id', isNotEqualTo: excludeId);
      }
      final QuerySnapshot snapshot = await query.get();
      return snapshot.docs.isNotEmpty;
    } catch (e) {
      debugPrint('خطأ في التحقق من وجود الرقم التسلسلي: $e');
      return false;
    }
  }

  // جلب جهاز بواسطة الباركود أو Asset Code
  static Future<DeviceModel?> getDeviceByBarcode(
      String barcode, String assetCode) async {
    try {
      // Firestore لا يدعم OR مباشرة بين حقول مختلفة بنفس الطريقة
      // سنقوم بإجراء استعلامين ودمج النتائج
      final QuerySnapshot barcodeSnapshot = await _firestore
          .collection('devices')
          .where('universityBarcode', isEqualTo: barcode)
          .limit(1)
          .get();
      if (barcodeSnapshot.docs.isNotEmpty) {
        return DeviceModel.fromMap(
            barcodeSnapshot.docs.first.data() as Map<String, dynamic>);
      }

      final QuerySnapshot assetCodeSnapshot = await _firestore
          .collection('devices')
          .where('assetCode', isEqualTo: assetCode)
          .limit(1)
          .get();
      if (assetCodeSnapshot.docs.isNotEmpty) {
        return DeviceModel.fromMap(
            assetCodeSnapshot.docs.first.data() as Map<String, dynamic>);
      }
      return null;
    } catch (e) {
      debugPrint('خطأ في جلب الجهاز بواسطة الباركود/Asset Code: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // دوال مساعدة لـ Firebase Storage (لتخزين الصور)
  // ---------------------------------------------------------------------------

  // رفع صورة إلى Firebase Storage
  static Future<String?> uploadImageToFirebaseStorage(
      File imageFile, String storagePath) async {
    try {
      final ref = _storage.ref().child(storagePath);
      // إضافة metadata فارغة لتجنب NullPointerException
      final uploadTask =
          ref.putFile(imageFile, SettableMetadata()); // <--- التغيير هنا
      final snapshot = await uploadTask.whenComplete(() {});
      final downloadUrl = await snapshot.ref.getDownloadURL();
      debugPrint('تم رفع الصورة بنجاح: $downloadUrl');
      return downloadUrl;
    } catch (e) {
      debugPrint('خطأ في رفع الصورة إلى Storage: $e');
      return null;
    }
  }

  // حذف صورة من Firebase Storage
  static Future<void> _deleteImageFromFirebaseStorage(
      String storagePath) async {
    try {
      final ref = _storage.ref().child(storagePath);
      await ref.delete();
      debugPrint('تم حذف الصورة من Storage: $storagePath');
    } catch (e) {
      debugPrint('خطأ في حذف الصورة من Storage (قد لا تكون موجودة): $e');
    }
  }

  // ---------------------------------------------------------------------------
  // دوال مساعدة أخرى (توليد ID)
  // ---------------------------------------------------------------------------

  // توليد معرف فريد (يمكن استخدامه لـ Firestore Document IDs)
  static String generateUniqueId() {
    return const Uuid().v4();
  }
}
