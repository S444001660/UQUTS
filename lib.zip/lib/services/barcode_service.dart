import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart'; // مكتبة لتوفير واجهة مسح الباركود.
import 'dart:developer'
    as developer; // مكتبة لتسجيل الأخطاء والرسائل التشخيصية المتقدمة.
import 'package:flutter/material.dart'; // تم إضافة هذا الاستيراد لاستخدام BuildContext و ScaffoldMessenger

// كلاس خدمي (Service Class) مركزي للتعامل مع جميع العمليات المتعلقة بالباركود.
// استخدام كلاس خدمي يجمع المنطق المتعلق بميزة معينة في مكان واحد.
class BarcodeService {
  // دالة ثابتة (static) غير متزامنة لمسح الباركود.
  // تم إضافة BuildContext context كوسيطة هنا.
  static Future<String?> scanBarcode(BuildContext context) async {
    // تم إضافة BuildContext context
    try {
      // استدعاء دالة المسح من المكتبة وتمرير الإعدادات.
      final result = await FlutterBarcodeScanner.scanBarcode(
        '#ff6666', // لون خط المسح.
        'إلغاء', // نص زر الإلغاء.
        true, // عرض ضوء الفلاش.
        ScanMode.BARCODE, // وضع المسح (باركود).
      );

      // المكتبة تعيد '-1' إذا قام المستخدم بإلغاء عملية المسح.
      if (result == '-1') {
        // تسجيل معلومة بأن المستخدم ألغى العملية (لأغراض التشخيص).
        developer.log('Barcode scan cancelled by user',
            name: 'BarcodeService', level: 300 // مستوى المعلومة (INFO).
            );
        return null; // إرجاع قيمة فارغة للدلالة على الإلغاء.
      }

      // تسجيل نجاح عملية المسح مع قيمة الباركود.
      developer.log('Barcode scanned successfully',
          name: 'BarcodeService',
          level: 800, // مستوى دقيق (FINE).
          error: result);
      return result; // إرجاع قيمة الباركود الممسوح.
    } catch (e) {
      // تسجيل أي خطأ يحدث أثناء عملية المسح.
      developer.log('Error during barcode scanning',
          name: 'BarcodeService',
          level: 1000, // مستوى الخطورة (SEVERE).
          error: e,
          stackTrace: StackTrace.current);
      // يمكنك عرض SnackBar أو Dialog هنا لإظهار الخطأ إذا أردت
      // مثال:
      // if (context.mounted) { // التحقق من mounted قبل استخدام context في async
      //   ScaffoldMessenger.of(context).showSnackBar(
      //     SnackBar(content: Text('خطأ في مسح الباركود: $e')),
      //   );
      // }
      return null; // إرجاع قيمة فارغة في حالة حدوث خطأ.
    }
  }

  // دالة ثابتة لتحليل باركود الجامعة ومحاولة تقسيمه إلى بيانات مفهومة.
  // تعالج الدالة عدة تنسيقات محتملة للباركود.
  static Map<String, String?> parseUniversityBarcode(String barcode) {
    try {
      // 1. تنظيف سلسلة الباركود من المسافات الزائدة في البداية والنهاية والوسط.
      barcode = barcode.trim().replaceAll(RegExp(r'\s+'), '');

      // 2. محاولة التعامل مع التنسيق الأول: "جامعة أم القرى اسم الأصل / الآلات والمعدات رمز الأصل / 0022958"
      if (barcode.contains('/') && barcode.split('/').length == 3) {
        final parts = barcode.split('/');
        return {
          'barcode': barcode,
          'assetSource': parts[0].trim(),
          'assetCategory': parts[1].trim(),
          'assetCode': parts[2].trim(),
        };
      }

      // 3. محاولة التعامل مع التنسيق الثاني: رقم تسلسلي بسيط (فقط أرقام).
      if (RegExp(r'^\d+$').hasMatch(barcode)) {
        return {
          'barcode': barcode,
          'assetSource': 'جامعة أم القرى', // قيمة افتراضية
          'assetCategory': 'معدات', // قيمة افتراضية
          'assetCode': barcode,
        };
      }

      // 4. محاولة التعامل مع التنسيق الثالث: "UQU-ASSET-0012498-COMPUTER"
      if (barcode.contains('UQU-ASSET-')) {
        final parts = barcode.split('-');
        return {
          'barcode': barcode,
          'assetSource': 'جامعة أم القرى',
          'assetCategory': parts.length > 3 ? parts[3] : 'معدات',
          'assetCode': parts.length > 2 ? parts[2] : barcode,
        };
      }

      // 5. محاولة احتياطية: استخراج أي سلسلة من الأرقام (6 أرقام أو أكثر) من أي نص.
      final assetCodeMatch = RegExp(r'\d{6,}').firstMatch(barcode);
      if (assetCodeMatch != null) {
        return {
          'barcode': barcode,
          'assetSource': 'جامعة أم القرى',
          'assetCategory': 'معدات',
          'assetCode': assetCodeMatch.group(0), // .group(0) يعيد النص المطابق.
        };
      }

      // 6. محاولة أخيرة: تنظيف الباركود بإزالة كل ما هو ليس رقمًا.
      final cleanedBarcode = barcode.replaceAll(RegExp(r'[^0-9]'), '');
      if (cleanedBarcode.isNotEmpty) {
        return {
          'barcode': barcode,
          'assetSource': 'جامعة أم القرى',
          'assetCategory': 'معدات',
          'assetCode': cleanedBarcode,
        };
      }

      // 7. في حال فشل كل المحاولات، يتم إرجاع الباركود الأصلي كرمز للأصل.
      return {
        'barcode': barcode,
        'assetSource': 'جامعة أم القرى',
        'assetCategory': 'معدات',
        'assetCode': barcode,
      };
    } catch (e) {
      // تسجيل أي خطأ غير متوقع أثناء عملية التحليل.
      developer.log('Error parsing barcode',
          name: 'BarcodeService',
          level: 1000,
          error: e,
          stackTrace: StackTrace.current);
      // إرجاع قيمة آمنة في حالة الخطأ لضمان عدم توقف التطبيق.
      return {
        'barcode': barcode,
        'assetSource': 'جامعة أم القرى',
        'assetCategory': 'معدات',
        'assetCode': null,
      };
    }
  }

  // دالة ثابتة لإنشاء سلسلة باركود متوافقة مع التنسيقات المعروفة.
  static Future<String> generateBarcode({
    String? assetSource,
    String? assetCategory,
    required String assetCode,
  }) async {
    // إنشاء باركود بتنسيقات مختلفة بناءً على البيانات المتاحة.
    if (assetSource != null && assetCategory != null) {
      // إنشاء باركود بالتنسيق الأول (المفصول بـ /).
      return '$assetSource / $assetCategory / $assetCode';
    } else {
      // إنشاء باركود بالتنسيق الثاني (UQU-ASSET).
      return 'UQU-ASSET-$assetCode-${assetCategory ?? 'DEVICE'}';
    }
  }
}
